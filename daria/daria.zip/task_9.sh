ls > task_10.txt
